repo: andriyadi2025/exoclean
branch: main

## Last sync
date: 2026-08-26T00:00:00Z
note: repository is empty (no commits on main — tree endpoint returns 409), so nothing was imported. Screens were built from the brief plus the two Play Store references.

### Updated in this project
- Added EXOCLEAN mobile app prototype (customer + partner) on the Organic design system.
- Marketplace booking flow: cleaner rates, schedule-lock, validated vouchers.
- Guarantee/refund tracker patterns derived from competitor 1-star reviews.

## Screen map
| Project screen | Repo files |
| --- | --- |
| EXOCLEAN App.dc.html — all screens | (none yet — repo empty) |
