# Handoff: EXOCLEAN — aplikasi marketplace jasa kebersihan

## Ringkasan
EXOCLEAN adalah marketplace jasa kebersihan untuk pasar Indonesia (peluncuran Jabodetabek), dengan tagline **"We clean all purpose"**. Tiga produk dalam satu sistem:

1. **Aplikasi pelanggan** — memesan 16 jenis layanan, memilih sendiri petugasnya beserta tarif masing-masing, membayar, melacak, dan menerima laporan foto sebelum–sesudah.
2. **Aplikasi mitra (petugas)** — menerima job, rute ke lokasi, checklist SOP dengan bukti foto, dompet dan penarikan dana.
3. **Konsol admin (web)** — 14 modul operasi: live ops, harga, CRM, SOP & QC, meja keluhan, klaim, promo, poin & cashback, tampilan merek, peran, dan admin.

Posisi produk dibangun dari keluhan bintang satu pesaing (bTaskee, KliknClean): jadwal yang tidak bisa digeser sepihak, refund bertanggal, voucher divalidasi sebelum bayar, dan bukti kerja yang tidak bisa dibantah.

## Tentang berkas desain
Berkas HTML di paket ini adalah **referensi desain**, bukan kode produksi. Semuanya prototipe yang menunjukkan tampilan dan perilaku yang dimaksud. Tugasnya adalah **membangun ulang desain ini di lingkungan kode target** (React Native / Flutter untuk mobile, React/Next.js untuk konsol admin) memakai pola dan pustaka yang sudah ada di sana. Jika belum ada basis kode sama sekali, pilih kerangka kerja yang paling sesuai lalu implementasikan desainnya di sana.

Catatan teknis: berkas `.dc.html` adalah komponen desain berbasis React yang dirender lewat `support.js`. Logikanya ada di blok `<script data-dc-script>` di bagian bawah tiap berkas dan **dapat dibaca sebagai spesifikasi perilaku** — struktur data, aturan harga, mesin status, dan kamus terjemahan di sana adalah sumber kebenaran.

## Tingkat kedetailan
**High-fidelity.** Warna, tipografi, jarak, satuan, aturan harga, dan alur interaksi sudah final. Bangun ulang setepat mungkin memakai pustaka yang ada di basis kode Anda.

Yang **masih simulasi** dan harus diganti integrasi nyata:
- Peta dan GPS (placeholder) → Google Maps SDK
- Pembayaran (wallet, QRIS, e-wallet, VA, kartu) → payment gateway
- OTP WhatsApp/SMS, captcha, login Google & Facebook
- Data wilayah (11 negara ASEAN + 38 provinsi Indonesia dimuat sebagian) → API Kemendagri, **simpan kode wilayah, bukan namanya**
- Foto layanan dan foto petugas masih placeholder

---

## Design tokens

Diambil dari sistem desain **Organic** (`_ds/organic-7f8ca128-c44c-4416-900d-ccf7e6436e6c/styles.css`) dengan palet aksen diganti warna resmi logo EXOCLEAN.

### Warna
Aksen utama **#109080** dan aksen kedua **#70d0c0** — keduanya diambil langsung dari piksel logo.

| Step | Accent (utama) | Accent-2 (kedua) |
| --- | --- | --- |
| 100 | #e5f4f1 | #edf9f7 |
| 200 | #c7eae4 | #d9f2ee |
| 300 | #9edcd2 | #b9e8e0 |
| 400 | #54bdb0 | #a3e4d8 |
| 500 | **#109080** | **#70d0c0** |
| 600 | #0d8072 | #4bb8a7 |
| 700 | #0b6b60 | #329c8c |
| 800 | #08544b | #26786c |
| 900 | #063c36 | #1a564d |

Netral dan ground:

| Token | Nilai | Pakai untuk |
| --- | --- | --- |
| `--color-bg` | #f3faf8 | latar layar |
| `--color-surface` | #e6f2ef | kartu, kolom isian, ubin |
| `--color-divider` | #cce2dd | garis pemisah |
| `--color-text` | #201e1d | seluruh teks |
| `--color-neutral-200` | #e6f0ed | chip netral |
| `--color-neutral-300` | #d3e3df | track progress, tombol nonaktif |
| latar kanvas | #dceae7 | latar di luar bingkai ponsel |

Aturan pemakaian: teks berukuran paragraf di atas ground terang memakai step 700–900, bukan 500. Chip status memakai tiga tingkat — isi solid (aksen 500) untuk butuh tindakan, outline (garis aksen 400) untuk sehat, abu netral untuk informasi biasa.

### Tipografi
- Judul: **Caprasimo** (`--font-heading`)
- Isi: **Figtree** (`--font-body`)
- Skala di aplikasi: judul layar 25px, judul kartu 15–17px, isi 12,5–13,5px, keterangan 11–11,5px, angka besar 26–38px
- Konsol admin: judul halaman 24px, judul kartu 17px, isi tabel 12–12,5px

### Bentuk & bayangan
- Radius: kartu 22–26px, ubin 20–22px, tombol dan chip 999px (pil), kolom isian 999px kecuali textarea 22px
- Bayangan: `--shadow-sm` / `md` / `lg` dari sistem desain; jangan buat sendiri
- Ikon: Lucide, **stroke-width 2.75**

### Jarak
Skala `--space-*` sistem Organic (density 1,1×). Di aplikasi: padding layar 18–20px, jarak antar kartu 14px, jarak dalam kartu 9–12px.

---

## Aplikasi pelanggan — 20 layar

| Kunci | Nama | Tujuan |
| --- | --- | --- |
| `onboard` | Onboarding | Pengenalan janji produk, masuk lewat nomor telepon |
| `signup` | Daftar · verifikasi & PIN | Login Google/Facebook/telepon, captcha, OTP 2 langkah, buat PIN transaksi 6 digit |
| `home` | Beranda | Alamat aktif, pencarian, running text promo, 9 ubin layanan cepat, kartu janji, kunjungan berikutnya, petugas terdekat |
| `catalog` | Semua layanan | 16 layanan dalam 3 grup (Rumah & rutin, Teknis & berkala, Bisnis) dengan tarif terendah dan garansi |
| `svc` | Booking langkah 1 | Kuantitas per satuan, jumlah petugas, tanggal, jam, add-on, kartu survei (untuk layanan bersurvei), kartu garansi |
| `cleaner` | Booking langkah 2 | Marketplace petugas: tarif masing-masing, rating, jarak, tag kepercayaan, total per petugas |
| `review` | Booking langkah 3 | Ringkasan, voucher tervalidasi, 5 metode bayar, rincian biaya, konfirmasi PIN |
| `success` | Terkonfirmasi | Nomor order, metode bayar, total, garansi |
| `track` | Pelacakan langsung | Peta, tahapan status, checklist berjalan, kontak petugas dan CS |
| `report` | Laporan sebelum–sesudah | Foto per area berstempel waktu dan lokasi, tidak bisa diedit petugas |
| `orders` | Pesanan | Akan datang / lampau, langganan berulang, pelacak refund bertanggal |
| `wallet` | Dompet | Saldo, poin, tier, riwayat transaksi |
| `prepaid` | Paket prepaid | 3 paket (10/20/40 jam) dengan masa aktif dan penghematan |
| `rate` | Penilaian | Bintang, tag pujian, catatan, tip 100% untuk petugas |
| `issue` | Klaim garansi | 5 jenis masalah, foto, hasil yang dijanjikan per jenis |
| `share` | Bagikan & referral | 3 jenis kartu (referral, hasil, rekomendasi petugas) ke 8 kanal |
| `terms` | Ketentuan & privasi | 4 tab: umum, layanan ini, prepaid, privasi |
| `lang` | Bahasa | 12 bahasa |
| `profile` | Profil | Alamat tersimpan, petugas favorit, pengaturan, kartu referral |

## Aplikasi mitra — 7 layar

| Kunci | Nama | Tujuan |
| --- | --- | --- |
| `preg` | Pendaftaran mitra | Alamat berjenjang (negara → provinsi → kab/kota → kecamatan → desa → kode pos) + titik peta, **2 nomor kontak darurat wajib ber-OTP**, radius area kerja dari titik rumah |
| `pjobs` | Feed job | Status online, penghasilan minggu ini, job berjalan, permintaan terbuka |
| `pjob` | Job berjalan | Detail pelanggan, catatan akses, checklist, rincian bayaran |
| `proute` | Rute ke lokasi | Navigasi, tombol tiba di lokasi |
| `psop` | Checklist SOP | Gerbang APD per layanan, checklist alat & chemical, langkah kerja berurutan dengan foto wajib |
| `preport` | Laporan sebelum–sesudah | Unggah foto per area, kirim ke pelanggan |
| `pearn` + `pwallet` | Penghasilan & dompet | Grafik 7 hari, standing, **penarikan wajib rekening atas nama sendiri + PIN 6 digit** |

## Konsol admin — 14 modul

Lebar kanvas 1440px, sidebar 248px.

`dash` Dashboard · `live` Live ops (peta armada, GPS, keterlambatan) · `orders` Pesanan · `cleaners` Petugas (antrian verifikasi dokumen + roster) · `services` Layanan & harga (**16 layanan, floor/ceiling bisa diketik, publish/revert**) · `crm` CRM (lifecycle, segmen, customer 360, automation) · `sop` SOP & QC (87 dokumen terkontrol, penugasan kontrak, inspeksi & CAPA) · `desk` Meja keluhan (S1–S4 dengan SLA, antrian per tenggat, root cause, tangga eskalasi) · `claims` Klaim & refund · `promos` Promo & voucher · `rewards` Poin & cashback · `brand` Tampilan (unggah logo, warna, nama app, publish runtime) · `roles` Peran & izin (8 peran × 14 fungsi) · `team` Admin.

---

## Aturan bisnis yang wajib dipertahankan

Ini bukan detail tampilan — ini inti produknya.

1. **Slot terkunci.** Setelah dikonfirmasi, hanya pelanggan yang bisa memindahkan jadwal. Tidak ada peran admin mana pun — termasuk super admin — yang boleh menggesernya. Bila sistem yang memindahkan, Rp100.000 kredit masuk otomatis ke dompet pelanggan.
2. **Harga satu sumber.** Tarif yang dibayar = tarif petugas terpilih. `rateFor(cleaner) = round(service.rate × cleaner.factor)`. Faktor: Sari 0,92 · Nurul 0,85 · Ayu 1,04 · Dian 0,76. Label "From" di langkah 1 memakai tarif terendah di pasar.
3. **Satuan mengikuti layanan.** /jam, /unit, /dudukan, /kg, /ruangan, /mobil, /kunjungan, /m², /toren. Default kuantitas, langkah naik-turun, dan batas berbeda per satuan (m² kelipatan 4, mulai 12).
4. **Voucher divalidasi terhadap keranjang sebelum bayar**, lengkap dengan alasan bila tidak memenuhi syarat (mis. minimum Rp150.000).
5. **Biaya platform flat Rp3.000**, tanpa surge, di semua layanan.
6. **Pembatalan/reschedule di bawah 4 jam**: Rp50.000 per petugas. Petugas menunggu maksimal 45 menit (AC 30 menit).
7. **Refund selalu ke EXO Wallet**, maksimal 3 hari kerja, dengan tanggal jatuh tempo yang terlihat pelanggan. Lewat tenggat = kredit otomatis.
8. **APD wajib per layanan.** Semua APD yang tercantum di SOP layanan itu harus dicentang sebelum langkah kerja terbuka. Jumlahnya beda-beda: setrika 1, general 2, fogging & pest 6, tangki gedung 7 (termasuk harness dan detektor gas).
9. **Langkah kerja berurutan.** Langkah N terkunci sampai N−1 selesai. Langkah bertanda foto tidak bisa ditutup tanpa foto sebelum–sesudah berstempel waktu dan lokasi.
10. **Penarikan mitra** hanya ke rekening atas nama sendiri (dikunci nama KTP), wajib PIN 6 digit, ganti rekening butuh OTP dan menunda penarikan 24 jam.
11. **Pemisahan tugas.** Yang mengajukan klaim tidak boleh menyetujuinya. Refund di atas Rp5jt butuh Finance + Super admin.
12. **Frequency cap lintas kanal**: maksimal 2 pesan marketing per minggu dihitung gabungan. Pesan operasional selalu menang. Pelanggan dengan klaim terbuka atau rating ≤3 dikecualikan dari semua kampanye.

## Multi-bahasa

12 bahasa: **en, id, ja, ko, zh, ar, ms, th, vi, tl, km, my**. Bahasa Arab memakai tata letak kanan-ke-kiri (`dir="rtl"`).

Dua mekanisme terjemahan di kode:
- `this.T` — kamus berkunci semantik (`t('quickBook')`), untuk label UI
- `this.STR` — kamus berkunci string sumber Inggris (`tx('Available cleaners')`), untuk teks dari array data

Nama hari dan tanggal dibentuk lewat `Intl.DateTimeFormat` dengan peta locale (`LOCALES`), bukan literal. Nama layanan, teks garansi, label satuan, dan kata hitung punya peta terjemahan sendiri.

Saat produksi, pindahkan semua kamus ini ke berkas locale (JSON per bahasa) dan gunakan pustaka i18n standar di kerangka kerja Anda.

## State yang dibutuhkan

Dari kelas logika aplikasi pelanggan: `lang`, `screen`, `sideOverride`, `svc`, `hours` (kuantitas), `crew`, `day`, `time`, `addons`, `cleaner`, `pay`, `voucher`, `pin`, `stage`, `stars`, `praise`, `tip`, `issue`, `orderTab`, `filter`, `checks`, `prepaid`, `addr`, `kin`, `radius`, `bank`, `wdAmount`, `wdMethod`, `wdPin`, `ppe`, `kit`, `sopDone`, `photos`.

## Aset

- `assets/exoclean-mark.png` — lambang persegi (sumber: unggahan pengguna, 1024×1024 transparan)
- `assets/exoclean-wordmark.png`, `assets/exoclean-lockup.png` — turunan dari lambang yang sama
- Foto layanan, foto petugas, dan peta masih placeholder — perlu materi asli

## Berkas dalam paket ini

| Berkas | Isi |
| --- | --- |
| `EXOCLEAN App.dc.html` | Aplikasi pelanggan + aplikasi mitra (27 layar, satu berkas) |
| `EXOCLEAN Admin.dc.html` | Konsol admin (14 modul) |
| `EXOCLEAN Perbandingan Layanan.dc.html` | Matriks 20 layanan vs pesaing |
| `EXOCLEAN Analisa Kompetitor.dc.html` | Analisa kelebihan/kekurangan dan prioritas |
| `support.js` | Runtime perender berkas `.dc.html` |
| `android-frame.jsx` | Bingkai perangkat Android untuk pratinjau |
| `_ds/organic-.../` | Sistem desain Organic (token, kelas komponen) |
| `assets/` | Logo |
| `dokumen-sop/` | SOP, checklist, dan formulir asli dari pengguna (rujukan modul SOP & QC) |

Buka berkas `.dc.html` langsung di peramban untuk melihat desainnya berjalan.
